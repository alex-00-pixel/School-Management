#include"calcu_cgpa.cpp"
using namespace std;

//making the object of class 

calculate cal;